    <link rel="icon" type="image/png" href="{{ asset('jobbey/assets/images/fav.png') }}">
    <link href="{{ asset('jobbey/assets/css/responsive.css') }}" rel="stylesheet">
    <link href="{{ asset('jobbey/assets/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('jobbey/assets/css/datepicker.min.css') }}" rel="stylesheet">
    <link href="{{ asset('jobbey/assets/css/jquery.range.css') }}" rel="stylesheet">
    <link href="{{ asset('jobbey/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('jobbey/assets/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <link href="{{ asset('jobbey/assets/vendor/OwlCarousel/assets/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ asset('jobbey/assets/vendor/OwlCarousel/assets/owl.theme.default.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('jobbey/assets/vendor/semantic/semantic.min.css') }}">