<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=9">
    <meta name="description" content="Gambolthemes">
    <meta name="author" content="Gambolthemes">
    <title>Jobby - Browse Jobs</title>
    
    <?php echo $__env->make('jobbey.layouts.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
     
     <?php echo $__env->make('jobbey.layouts.searchmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
      <?php echo $__env->make('jobbey.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
      <?php echo $__env->make('jobbey.layouts.titlebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <main class="browse-section">
        <div class="container">
            <div class="row">
                 
                 <?php $__env->startSection('main-content'); ?>
                 <?php echo $__env->yieldSection(); ?>

               
            </div>
        </div>
    </main>
   
    <?php echo $__env->make('jobbey.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   

        <?php echo $__env->make('jobbey.layouts.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>


</html><?php /**PATH C:\xampp\htdocs\eightauth\resources\views/jobbey/layouts/app.blade.php ENDPATH**/ ?>