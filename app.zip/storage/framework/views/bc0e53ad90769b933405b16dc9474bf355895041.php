    <div class="title-bar">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ol class="title-bar-text">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('job.alljob')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Browser Jobs</li>
                    </ol>
                </div>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\eightauth\resources\views/jobbey/layouts/titlebar.blade.php ENDPATH**/ ?>