    <header>
        <div class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="top-header-full">
                            <div class="top-left-hd">
                                <ul>
                                    <li>
                                        <div class="wlcm-text">Welcome to Jobby</div>
                                    </li>
                                    <li>
                                        <div class="lang-icon dropdown">
                                            <i class="fas fa-globe ln-glb"></i>
                                            <a href="jobbey/assets/#" class="icon15 dropdown-toggle-no-caret" role="button" data-toggle="dropdown">
                                                EN <i class="fas fa-caret-down p-crt"></i>
                                            </a>
                                            <div class="dropdown-menu lanuage-dropdown dropdown-menu-left">
                                                <a class="link-item" href="jobbey/assets/#">EN</a>
                                                <a class="link-item" href="jobbey/assets/#">DE</a>
                                                <a class="link-item" href="jobbey/assets/#">RU</a>
                                                <a class="link-item" href="jobbey/assets/#">ES</a>
                                                <a class="link-item" href="jobbey/assets/#">FR</a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                              <?php echo $__env->make('jobbey.layouts.topright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php echo $__env->make('jobbey.layouts.subheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header><?php /**PATH C:\xampp\htdocs\eightauth\resources\views/jobbey/layouts/header.blade.php ENDPATH**/ ?>