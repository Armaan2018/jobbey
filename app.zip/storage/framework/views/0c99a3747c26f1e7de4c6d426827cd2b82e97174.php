

<?php $__env->startSection('main-content'); ?>
            <div class="row justify-content-md-center">
                <div class="col-md-6">
                    <div class="lg_form">
                        <div class="main-heading">
                            <h2>Sign in to Jobby</h2>
                            <div class="line-shape1">
                                <img src="<?php echo e(URL::to('')); ?>/jobbey/assets/images/line.svg" alt="">
                            </div>
                        </div>

                        <form action="<?php echo e(route('user.login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label class="label15">Email Address*</label>
                            <input type="email" name="email" class="job-input" placeholder="Enter Email Address">
                        </div>
                        <div class="form-group">
                            <label class="label15">Password*</label>
                            <input type="password" name="password" class="job-input" placeholder="Enter Password">
                        </div>
                        <button class="lr_btn" type="submit">Sign in Now</button>
                        <div class="done145">
                            <div class="done146">
                                Need an account?<a href="sign_up.html">Join us Now<i class="fas fa-angle-double-right"></i></a>
                            </div>
                            <div class="done147">
                                <a href="forgot_password.html">Forgot Password?</a>
                            </div>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('jobbey.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eightauth\resources\views/jobbey/users/userlogin.blade.php ENDPATH**/ ?>