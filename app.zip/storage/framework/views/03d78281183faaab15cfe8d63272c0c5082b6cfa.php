

<?php $__env->startSection('main-content'); ?>
<?php if(Auth::check()): ?>
    <?php $__currentLoopData = $single; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
       $ele_bud = json_decode($element -> budget);
       $skill   = json_decode($element -> test_skill);
       $get_bud = $ele_bud -> type_of;
       $get_bud_min = $ele_bud -> min;
       $get_bud_max = $ele_bud -> max;

     if ($get_bud == 'fp2'){
            $get_bud = 'Fixed';
      }else{
       $get_bud = 'Hourly';

      }
    ?>
<?php $__currentLoopData = $element -> users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-lg-9 col-md-8">
                    <div class="view_details">
                        <ul>
                            <li>
                                <div class="vw_items">
                                    <i class="fas fa-eye"></i>
                                    <div class="vw_item_text">
                                        <h6>Views</h6>
                                        <span>135</span>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="vw_items">
                                    <i class="fas fa-shield-alt"></i>
                                    <div class="vw_item_text">
                                        <h6>Verify</h6>
                                        <span>Yes</span>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="vw_items">
                                    <i class="far fa-money-bill-alt"></i>
                                    <div class="vw_item_text">
                                        <h6><?php echo e($get_bud); ?></h6>
                                        <span>$<?php echo e($get_bud_min); ?> - $<?php echo e($get_bud_max); ?></span>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="vw_items">
                                    <i class="far fa-clock"></i>
                                    <div class="vw_item_text">
                                        <h6>Posted Date</h6>
                                        <span><?php echo e($element -> created_at ->diffForHumans()); ?></span>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="job-item ptrl_2 mt-20">
                        <div class="job-top-dt">
                            <div class="job-left-dt">
                                <img src="<?php echo e(URL::to('')); ?>/public/media/work/<?php echo e($user -> profileimage); ?>" alt="">
                                <div class="job-ut-dts">
                                    <a href="#">
                                        <h4><?php echo e($user -> name); ?></h4>
                                    </a>
                                    <span><i class="fas fa-map-marker-alt"></i> <?php echo e($element -> location); ?></span>
                                </div>
                            </div>
                            <div class="job-right-dt">
                                <div class="job-price">$<?php echo e($get_bud_min); ?> - $<?php echo e($get_bud_min); ?></div>
                            </div>
                        </div>
                        <div class="job-des-dt">
                            <h4><?php echo e($element -> title); ?></h4>
                            <p><?php echo e($element -> description); ?></p>
                            <div class="job-skills">
                                <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#"><?php echo e($skills); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               

                            </div>
                        </div>
                        <div class="job_dts">
                            <h4>Attachments</h4>
                            <ul class="download_files">
                                <li>
                                    <div class="dwn_fls">
                                        <div class="dwn-header">
                                            <h6>Project Briefing Details</h6>
                                        </div>
                                        <div class="dwn-footer">
                                            <span>PDF</span>
                                            <button class="download_button"><i class="fas fa-download"></i></button>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="dwn_fls">
                                        <div class="dwn-header">
                                            <h6>Images</h6>
                                        </div>
                                        <div class="dwn-footer">
                                            <span>Zip</span>
                                            <button class="download_button"><i class="fas fa-download"></i></button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="find-lts-jobs">
                        <div class="main-heading bids_heading">
                            <h2>Freelancers Bidding</h2>
                            <div class="line-shape1">
                                <img src="images/line.svg" alt="">
                            </div>
                        </div>
                        <div class="freelancers_bidings">

                            <?php $__currentLoopData = $element -> applieds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $appl -> users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <?php
                                $js_user = json_decode($getuser -> profile)
                            ?>
                                       <div class="job-item mt-30" id="applicants">
                                <div class="job-top-dt">
                                    <div class="job-left-dt">
                                        <img src="<?php echo e(URL::to('')); ?>/public/media/work/<?php echo e($getuser -> profileimage); ?>" alt="">
                                        <div class="job-ut-dts">
                                            <a href="#">

                                                
                                                       <h4><?php echo e($getuser -> name); ?></h4>
                                              
                                           
                                            </a>

                                            <span><i class="fas fa-map-marker-alt"></i> <?php echo e($js_user -> location); ?></span>
                                            <div class="star mt-2">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <span>4.9</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="job-right-dt job-right-dt78">


                                        <?php
                                           $get_bud = $appl -> bid_budget;
                                           $damn = Str::replace(',','-$',$get_bud);
                                        ?>



 
                                        <div class="job-price job-price78">$<?php echo e($damn); ?></div>
                                        <div class="job-fp dy_cl">in <?php echo e($appl -> delivary_days); ?> Days</div>
                                        <br>

                              
                                          
                                      
                                          <?php if(Auth::user()-> id == $user -> id): ?>

                                          <?php $__currentLoopData = $appl -> tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usertask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              
                                         


                                          <a href="" id="hire_req_id" hire_id_attr="<?php echo e($usertask -> id); ?>"><span  class="badge badge-success">Hire</span></a>
                                          <a href="" id="del_req_id" del_appli_attr="<?php echo e($appl -> id); ?>"><span  class="badge badge-warning">Cancel</span></a>


                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                          <?php endif; ?>
                                   
                                            
                                  
                                      
                                    </div>
                                </div>
                            </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                     

                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 mainpage">
                    <div class="total_days mtp_30">4 days 5 hours left</div>


<?php if(Auth::user() -> role == 'freelancer'): ?>


                    <h4 class="bid_title">Bid Now This Job</h4>

                    <form method="POST" id="bidding_form" action="<?php echo e(route('job.confirm')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="get_freelancer" value="<?php echo e(Auth::user() -> id); ?>">
                        <input type="hidden" name="get_task" value="<?php echo e($element -> id); ?>">
                    <div class="bid_amount">
                        <div class="fltr-items-heading">
                            <div class="fltr-item-left">
                                <h6>Set Your Minimal Rate <span>($)</span></h6>
                            </div>
                            <div class="fltr-item-right">
                                <a href="#">Clear</a>
                            </div>
                        </div>
                        <div class="filter-dd">
                            <div class="rg-slider">
                                <input class="rn-slider slider-input" type="hidden" name="bid_budget" value="5,500" />
                            </div>
                        </div>
                    </div>
                    <div class="dlvry_days">
                        <div class="fltr-items-heading">
                            <div class="fltr-item-left">
                                <h6>Set Your Delivery Time</h6>
                            </div>
                            <div class="fltr-item-right">
                                <a href="#">Clear</a>
                            </div>
                        </div>
                                                                                            <?php $__errorArgs = ['delivary_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="ui fluid search selection dropdown skills-search" id="protin">

                            <input name="delivary_days" type="hidden" value="" id="testdays">
                            <i class="dropdown icon"></i>
                            <input class="search" autocomplete="off" tabindex="0">
                            <span class="sizer" style=""></span>
                            <div class="default text">Select Days</div>
                            <div class="menu transition hidden" tabindex="-1">
                                <div class="item" data-value="5">5 Days</div>
                                <div class="item" data-value="10">10 Days</div>
                                <div class="item" data-value="15">15 Days</div>
                                <div class="item" data-value="20">20 Days</div>
                                <div class="item" data-value="25">25 Days</div>
                                <div class="item" data-value="30">30 Days</div>
                                <div class="item" data-value="50">50 Days</div>
                                <div class="item" data-value="70">70 Days</div>
                                <div class="item" data-value="120">120 Days</div>
                            </div>
                        </div>
                    </div>
                    <button class="apply_job_rt" type="submit">PLACE A BID</button>
                    </form>



                    <div class="bookmark_rt"><button class="bookmark1 mr-3" title="bookmark"><i class="fas fa-heart"></i></button>BOOKMARK</div>
                    <ul class="social-links">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
                <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('jobbey.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eightauth\resources\views/jobbey/singletask.blade.php ENDPATH**/ ?>